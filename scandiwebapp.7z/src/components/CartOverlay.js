import React, { Component } from "react";
import "./styles/mainCart.css";
import "./styles/cartOverlay.css"
import {Link} from "react-router-dom"
export default class cartOverlay extends Component {
  constructor(props) {
    super(props);
    this.state = {
        cart: this.props.cart,
        priceArray: this.props.priceArray,
    };
  }

  priceArray = [];
   /* updatePriceArray() {
    this.priceArray = [];
        this.state.cart.forEach((cartItem) => {
        console.log(cartItem)
        cartItem.element.prices.forEach((element) => {
          if (element.currency.label === this.props.currency) {
          const priceObj = {
            price: element.amount,
            currency: element.currency.label,
            label: element.currency.symbol,
          };
          this.priceArray.push(priceObj);
        }
      });
    });
  }*/

    total = () => {
    let total = 0;
        this.props.cart.forEach((element) => {
      total = total + (element.element.prices[0].amount*element.attr.count);
    });
    return total;
  };

    render() {
    let cartArray = null;
      if (this.props.cart.length > 0) {
        cartArray = this.props.cart.map((cartItem, index) => {
            if (index < 2) {
                return (
                <div className="itemContainer--cartOverlay">
                <div className="itemInfo--cartOverlay">
              <h1 className="apollo--cartOverlay">Apollo</h1>
              <h1 className="itemName--cartOverlay">{cartItem.element.name}</h1>
              <h1 className="itemPrice--cartOverlay">
                {cartItem.element.prices[0].currency.symbol}
                {cartItem.element.prices[0].amount}
              </h1>
              {cartItem.element.attributes.map((attr) => {
                  if (attr.type === "text") {
                      if (attr.name === "Size") {
                          return (
                              <div>
                        <h1 className="cartOverlayAttr--name">{attr.name}:</h1>
                        <div className="attrContainer--cartOverlay">
                          {attr.items.map((item) => {
                              return (
                                  <div
                                  title={cartItem.element.name}
                                  className="cartOverlayText--container"
                                  id={
                                      item.value == cartItem.attr.Size
                                      ? "cartText"
                                      : ""
                                    }
                                    >
                                {item.value}
                              </div>
                            );
                        })}
                        </div>
                      </div>
                    );
                }
                
                if (attr.name === "Capacity") {
                    return (
                        <div>
                        <h1 className="cartOverlayAttr--name">{attr.name}:</h1>
                        <div className="attrContainer--cartOverlay">
                          {attr.items.map((item) => {
                              return (
                                  <div
                                  className="cartOverlayText--container"
                                  id={
                                      item.value == cartItem.attr.Capacity
                                      ? "cartText"
                                      : ""
                                    }
                                    >
                                {item.value}
                              </div>
                            );
                        })}
                        </div>
                      </div>
                    );
                }
                
                if (attr.name === "Touch ID in keyboard") {
                    return (
                        <div>
                        <h1 className="cartOverlayAttr--name">{attr.name}:</h1>
                        <div className="attrContainer--cartOverlay">
                          {attr.items.map((item) => {
                              return (
                                  <div
                                  className="cartOverlayText--container"
                                  id={
                                  item.value == cartItem.attr.touchID
                                  ? "cartText"
                                  : ""
                                }
                                >
                                {item.value}
                              </div>
                            );
                        })}
                        </div>
                      </div>
                    );
                  }
                  if (attr.name === "With USB 3 ports") {
                      return (
                          <div>
                        <h1 className="cartOverlayAttr--name">{attr.name}:</h1>
                        <div className="attrContainer--cartOverlay">
                          {attr.items.map((item) => {
                              return (
                                  <div
                                  className="cartOverlayText--container"
                                  id={
                                      item.value == cartItem.attr.withUSB
                                      ? "cartText"
                                      : ""
                                    }
                                    >
                                {item.value}
                              </div>
                            );
                        })}
                        </div>
                      </div>
                    );
                }
            } else {
                return (
                    <div>
                      <h1 className="cartOverlayAttr--name">{attr.name}:</h1>
                      <div className="attrContainer--cartOverlay">
                        {attr.items.map((item) => {
                            return (
                                <div
                                style={{
                                    color: `${item.value}`,
                                    backgroundColor: `${item.value}`,
                                }}
                                className="cartOverlayColor--attr"
                                id={
                                    item.value == cartItem.attr.Color
                                    ? "cartColor"
                                    : ""
                                }
                                >
                              {item.value}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                }
            })}
            </div>
            <div className="cartOverlay--handle">
              <div className="cart--productCount">
                <div
                  className="cartOverlay--incr"
                  onClick={() => this.props.incrementCount(cartItem)}
                  >
                  +
                </div>
                <div className="cartOverlay--productNum">{cartItem.attr.count}</div>
                <div
                  className="cartOverlay--decr"
                  onClick={() => this.props.removeOrDecrement(cartItem)}
                  >
                  -
                </div>
              </div>
              <div className="cartOverlay--carousel">
                <img
                  className="cartOverlay--Image"
                  src={
                      cartItem.element.gallery[0]
                    }
                    ></img>
              </div>
            </div>
          </div>
        );
    }
      });
    }
    return (
      <div style={{display : this.props.display}}>
        {this.props.cart.length > 0 ? (
          <div className="cartOverlay">
            <h4 className="cartOverlayTitle">My Bag, <span>{this.props.quantity()}  items</span></h4>
            <div className="cartOverlay--info">{cartArray}</div>
            <h4 className="cartOverlay--total">
              total:{" "}
              <span>
                {this.props.cart[0].element.prices[0].currency.symbol}
                {(
                  Math.round((this.total() + this.total() * 0.21) * 100) / 100
                ).toFixed(2)}
              </span>
            </h4>
            <div className="buttonContainer--cartOverlay">
                        <Link style={{ textDecoration: "none" }} to="/mainCart">
                            <div className="cartOverlay--viewCart" onClick={() => this.props.disableOverlay()}>
                    <span>View Cart</span>
                </div></Link>
                <div className="cartOverlay--checkOut">
                    <span>Checkout</span>
                </div>            
            </div>
          </div>
        ) : (
          "no items"
        )}
      </div>
    );
  }
}
