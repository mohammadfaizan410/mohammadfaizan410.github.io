import {endPoint, graphQlQuery} from "./queryConst"
import axios from 'axios';
export const initialState = {
    cart : [],
    currentProduct : {},
    currency : ""
}