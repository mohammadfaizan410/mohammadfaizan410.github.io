import React, { Component } from "react";
import parser from "html-react-parser";
import "./styles/singleProduct.css";

export default class SingleProduct extends Component {
  state = {
    currentPic: this.props.item ? this.props.item.gallery[0] : "",
    attributes: {
      Size: "",
      Capacity: "",
      withUSB: "",
      touchID: "",
      Color: "",
      count: 1,
    },
  };

  stateAttr = this.state ? this.state.attributes : null;

  updateState() {
    if (this.props.item) {
      this.props.item.prices.forEach((item) => {
        if (item.currency.label === this.props.currency) {
          this.setState((state) => {
            return {
              ...state,
              price: item.amount,
              currency: item.currency.label,
              symbol: item.currency.symbol,
            };
          });
        }
      });
    }
  }

  handleSize = (e) => {
    this.setState((state) => {
      return {
        ...state,
        attributes: { ...state.attributes, Size: e.target.innerHTML },
      };
    });
  };

  handleUSB = (e) => {
    this.setState((state) => {
      return {
        ...state,
        attributes: { ...state.attributes, withUSB: e.target.innerHTML },
      };
    });
  };
  handleTouchID = (e) => {
    this.setState((state) => {
      return {
        ...state,
        attributes: { ...state.attributes, touchID: e.target.innerHTML },
      };
    });
  };

  handleCapacity = (e) => {
    this.setState((state) => {
      return {
        ...state,
        attributes: { ...state.attributes, Capacity: e.target.innerHTML },
      };
    });
  };
  handleColor = (e) => {
    this.setState((state) => {
      return {
        ...state,
        attributes: { ...state.attributes, Color: e.target.innerHTML },
      };
    });
  };

  render() {
    console.log(this.props.item)
    if (this.props.currency != this.state.currency) {
      this.updateState();
    }
    let gallery = null;
    let attrArray = null;
    if (this.props.item) {
      console.log(this.props.item)
      if (this.gallery == null) {
        gallery = this.props.item.gallery.map((element) => {
          return (
            <img
              key={this.element}
              onClick={() => {
                this.setState((state) => {
                  return {
                    ...state,
                    currentPic: element,
                  };
                });
              }}
              src={element}
              className="gallery--image"
              id={element === this.state.currentPic ? "selected" : ""}
            ></img>
          );
        });
      }
    }
    if (this.props.item) {
      attrArray = this.props.item.attributes.map((element) => {
        if (element.type === "text") {
          if (element.name === "Size") {
            return (
              <div>
                <h4>{element.name}:</h4>
                <div className="attr--container">
                  {element.items.map((item) => {
                    return (
                      <div
                        className="text--attr"
                        onClick={this.handleSize}
                        id={
                          this.state.attributes.Size === item.value
                            ? "textAttrSelected"
                            : ""
                        }
                      >
                        {item.value}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          }
          if (element.name === "Capacity") {
            return (
              <div>
                <h4>{element.name}:</h4>
                <div className="attr--container">
                  {element.items.map((item) => {
                    return (
                      <div
                        className="text--attr"
                        onClick={this.handleCapacity}
                        id={
                          this.state.attributes.Capacity === item.value
                            ? "textAttrSelected"
                            : ""
                        }
                      >
                        {item.value}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          }
          if (element.name === "Touch ID in keyboard") {
            return (
              <div>
                <h4>{element.name}:</h4>
                <div className="attr--container">
                  {element.items.map((item) => {
                    return (
                      <div
                        className="text--attr"
                        onClick={this.handleTouchID}
                        id={
                          this.state.attributes.touchID === item.value
                            ? "textAttrSelected"
                            : ""
                        }
                      >
                        {item.value}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          }
          if (element.name === "With USB 3 ports") {
            return (
              <div>
                <h4>{element.name}:</h4>
                <div className="attr--container">
                  {element.items.map((item) => {
                    return (
                      <div
                        className="text--attr"
                        onClick={this.handleUSB}
                        id={
                          this.state.attributes.withUSB === item.value
                            ? "textAttrSelected"
                            : ""
                        }
                      >
                        {item.value}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          }
        } else {
          if (element.name === "Color") {
            return (
              <div>
                <h4>{element.name}:</h4>
                <div className="attr--container">
                  {element.items.map((item) => {
                    return (
                      <div
                        style={{
                          backgroundColor: `${item.value}`,
                          color: `${item.value}`,
                        }}
                        className="color--attr"
                        onClick={this.handleColor}
                        id={
                          this.state.attributes.Color === item.value
                            ? "colorAttrSelected"
                            : ""
                        }
                      >
                        {item.value}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          }
        }
      });
    }
    return (
      <div>
        {this.props.item ? (
          <div className="singleProduct">
            <div className="gallery">{gallery}</div>
            <div>
              <img className="main--picture" src={this.state.currentPic}></img>
            </div>
            <div className="details">
              <h4 className="title">Apollo</h4>
              <h4 className="title">{this.props.item.name}</h4>
              <div>{attrArray}</div>
              <h4>Price:</h4>
              <h4>
                {this.state.symbol}
                {this.state.price}
              </h4>
              {this.props.item.inStock ?
              <div
              className="addToCart"
              onClick={() =>
                this.props.updateCart(this.props.item, this.state.attributes)
              }
              >
                <span className="cart--add">Add To Cart</span>
              </div>
                :
              <div
              className="outOfStock"
              >
                <span className="cart--outOfStock">Out of Stock!</span>
              </div>
              }
              <p>{parser(this.props.item.description)}</p>
            </div>
          </div>
        ) : (
          "please select an item first!"
        )}
      </div>
    );
  }
}