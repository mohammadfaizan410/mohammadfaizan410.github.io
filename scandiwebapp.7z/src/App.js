//ShortComings :
//cart overlay displays the total amount and price only in USD.
import React, { Component } from "react";
import Products from "./components/Products";
import "./components/styles/app.css";
import SingleProduct from "./components/SingleProduct";
import CartOverlay from "./components/CartOverlay";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { AiOutlineShoppingCart } from "react-icons/ai";
import MainCart from "./components/MainCart";
class App extends Component {
  state = {
    cart: [],
    currency: "USD",
    label: "$",
    currentItem: null,
    selectedLink: "allProducts",
    CartOverlayClicked: "none",
    };
    
  disableOverlay = () => {
    this.setState(prevState=>{
      return {
        ...prevState,
        CartOverlayClicked : "none"
      }

    })
  }
  
  handleCartOverlayClick = () => {
        if (this.state.CartOverlayClicked === "none") {
            this.setState(prevState => {
                return {
                    ...prevState,
                    CartOverlayClicked : "block"
            }
        })
        }
        else {
            this.setState(prevState => {
                return {
                    ...prevState,
                    CartOverlayClicked : "none"
            }
        })
        }
  }
  
  getPriceArray = (priceArray) => {
    this.setState(prevState => {
      return {
        ...prevState,
        priceArray : priceArray
      }
    })
    console.log(this.state.priceArray)
  }

  updateCurrentItem = (element) => {
    this.setState((state) => {
      return {
        ...state,
        currentItem: element,
      };
    });
  };

  updateSelectedLink = (e) => {
    this.setState((state) => {
      return {
        ...state,
        selectedLink: e.target.innerHTML,
      };
    });
  };

  cartItemCount = () => {
    let total = 0;
    this.state.cart.forEach((item) => {
      total = total + item.attr.count;
    });
    return total;
  };

  addOrUpdateCart = (element, attr) => {
    let flag = false;
    const tempArray = this.state.cart;
    if (tempArray.length > 0) {
      tempArray.forEach((item) => {
        if (item.element.name === element.name) {
          item.attr.count = item.attr.count + 1;
          flag = true;
        }
      });
      if (flag !== true) {
        tempArray.push({ element, attr });
        this.setState((prevState) => {
          return { ...prevState, cart: tempArray };
        });
      } else {
        this.setState((prevState) => {
          return { ...prevState, cart: tempArray };
        });
      }
    } else {
      this.setState((prevState) => {
        return {
          ...prevState,
          cart: [...prevState.cart, { element, attr }],
        };
      });
    }
  };

  removeOrDecrement = (element) => {
    const tempArray = this.state.cart;
    if (tempArray.length > 0) {
      tempArray.forEach((item, index) => {
        console.log(element.element.name);
        if (element.element.name === item.element.name) {
          if (element.attr.count > 1) {
            element.attr.count = element.attr.count - 1;
          } else {
            tempArray.splice(index, 1);
          }
        }
      });
      this.setState((prevState) => {
        return {
          ...prevState,
          cart: tempArray,
        };
      });
    }
  };
  incrCount = (element) => {
    const tempArray = this.state.cart;
    if (tempArray.length > 0) {
      tempArray.forEach((item) => {
        if (item.element.name === element.element.name) {
          element.attr.count = element.attr.count + 1;
        }
      });
      this.setState((prevState) => {
        return {
          ...prevState,
          cart: tempArray,
        };
      });
    }
  };

  emptyCart = () => {
    this.setState((prevState) => {
      return {
        ...prevState,
        cart: [],
      };
    });
  };

  handleCartAttrClick = (event, cartItem, attr) => {
    let cartArray = this.state.cart;
    if (cartArray.length > 0) {
      cartArray.forEach((item) => {
        if (item.element.name === cartItem.element.name) {
          item.attr[attr] = event.target.innerHTML;
        }
      });
    }
    this.setState((prevState) => {
      return {
        ...prevState,
        cart: cartArray,
      };
    });
  };
  handleCartTouchIdClick = (event, cartItem) => {
    let cartArray = this.state.cart;
    if (cartArray.length > 0) {
      cartArray.forEach((item) => {
        if (item.element.name === cartItem.element.name) {
          item.attr.touchID = event.target.innerHTML;
        }
      });
    }
    this.setState((prevState) => {
      return {
        ...prevState,
        cart: cartArray,
      };
    });
  };
  handleCartwithUSBClick = (event, cartItem) => {
    let cartArray = this.state.cart;
    if (cartArray.length > 0) {
      cartArray.forEach((item) => {
        if (item.element.name === cartItem.element.name) {
          item.attr.withUSB = event.target.innerHTML;
        }
      });
    }
    this.setState((prevState) => {
      return {
        ...prevState,
        cart: cartArray,
      };
    });
  };

  render() {
    return (
    <Router>    
        <div onClick={this.state.CartOverlayClicked==="block" ? this.disableOverlay : ""} className="app" id={this.state.CartOverlayClicked==="block" ? "cartOpen--app" : "" }>   
          <div className="app--nav">
            <Link
              to="/"
              style={{
                marginRight: "20px",
                marginLeft: "70px",
                textDecoration: "none",
              }}
            >
              <h3
                onClick={this.updateSelectedLink}
                className={
                  this.state.selectedLink === "allProducts" ? "selected" : ""
                }
              >
                allProducts
              </h3>
            </Link>

            <Link
              to="/"
              style={{ marginLeft: "100px", textDecoration: "none" }}
            >
              <h3
                onClick={this.updateSelectedLink}
                className={this.state.selectedLink === "tech" ? "selected" : ""}
              >
                tech
              </h3>
            </Link>

            <Link
              to="/"
              style={{ marginLeft: "100px", textDecoration: "none" }}
            >
              <h3
                onClick={this.updateSelectedLink}
                className={
                  this.state.selectedLink === "clothes" ? "selected" : ""
                }
              >
                 clothes
              </h3>
            </Link>
            <div className="cart">
              <select
                onChange={(e) =>
                  this.setState((state) => {
                    return {
                      ...state,
                      currency: e.target.value,
                      label: e.target.innerHTML,
                    };
                  })
                }
                value={this.state.currency}
              >
                <option value="USD">$</option>
                <option value="GBP">£</option>
                <option value="AUD">A$</option>
                <option value="JPY">¥</option>
              </select>
              <div>
                <span>
                    <AiOutlineShoppingCart
                    onClick={this.handleCartOverlayClick}
                    />            
                  <span className="count">
                    {this.state.cart.length > 0 ? this.cartItemCount() : 0}
                  </span>
                </span>
              </div>
            </div>
          </div>

          <Routes>
            <Route
              path="/"
              element={
                <Products
                  click={this.updateCurrentItem}
                  selectedLink={this.state.selectedLink}
                  currency={this.state.currency}
                />
              }
            />
            <Route
              path="singleProduct"
              element={
                <SingleProduct
                  item={this.state.currentItem}
                  currency={this.state.currency}
                  label={this.state.label}
                  updateCart={this.addOrUpdateCart}
                  
                />
              }
            />
                    
            <Route
              path="/mainCart"
              element={
                <MainCart
                  cart={this.state.cart}
                  currency={this.state.currency}
                  label={this.state.label}
                  quantity={this.cartItemCount}
                  removeOrDecrement={this.removeOrDecrement}
                  incrementCount={this.incrCount}
                  emptyCart={this.emptyCart}
                  handleCartAttrClick={this.handleCartAttrClick}
                  handleCartTouchIdClick={this.handleCartTouchIdClick}
                  handleCartwithUSBClick={this.handleCartwithUSBClick}
                  getPriceArray={this.getPriceArray}
                  priceArray = {this.state.priceArray}
                />
              }
                />
          </Routes>
        </div>
        <CartOverlay
        cart={this.state.cart}
        currency={this.state.currency}
        label={this.state.label}
        quantity={this.cartItemCount}
        removeOrDecrement={this.removeOrDecrement}
        incrementCount={this.incrCount}
        emptyCart={this.emptyCart} 
        display={this.state.CartOverlayClicked}
        disableOverlay = {this.disableOverlay}  
        />
      </Router>
    );
  }
}

export default App;
